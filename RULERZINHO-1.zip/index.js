const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT); // Recebe solicitações que o deixa online

const Discord = require("discord.js"); //Conexão com a livraria Discord.js
const client = new Discord.Client(); //Criação de um novo Client
const config = require("./config.json"); //Pegando o prefixo do bot para respostas de 
  
const db = require('quick.db')
const firebase = require('firebase')

client.on('message', async message => {
if (message.channel.type == "dm") return;
    let opan = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setDescription(`<a:coroa:784530332242018314>${message.author}<a:coroa:784530332242018314> 
Obrigado por me marca, meu prefixo é 'r!' use 'r!help' para saber meus comandos

[Me adicione](https://discord.com/oauth2/authorize?client_id=776259912837627925&scope=bot&permissions=8)
[Suporte](https://discord.gg/tZKKFzB8um)

`);

    let mention = [`<@${client.user.id}>`, `<@!${client.user.id}>`];
    mention.find(mention => {
        if (message.content === mention) {
            message.channel.send(opan);
        }
    });
});

var firebaseConfig = {
    apiKey: "AIzaSyAdpKfmq9NwV44DddtXdDhYOte5KOGkfJs",
    authDomain: "rullerzin.firebaseapp.com",
    databaseURL: "https://rullerzin-default-rtdb.firebaseio.com",
    projectId: "rullerzin",
    storageBucket: "rullerzin.appspot.com",
    messagingSenderId: "1069163256677",
    appId: "1:1069163256677:web:c8b9501e77fe6e4de69f8c",
    measurementId: "G-DJMHW16PWK"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
 const Database = firebase.database()
  
client.on('message', function(message) {
    if (message.channel.type == "dm") return;
    if (message.author.bot) return;
    
    Database.ref(`Servidores/levels/${message.guild.id}/${message.author.id}`)
    .once('value').then(async function(db) {
      if (db.val() == null) {
    Database.ref(`Servidores/levels/${message.guild.id}/${message.author.id}`)
    .set({
      xp: 0,
      level: 1
    });
      } else {
        let gerarXP = Math.floor(Math.random() *32) + 1;
        
        if (db.val().level*226 <= db.val().xp) {
    Database.ref(`Servidores/levels/${message.guild.id}/${message.author.id}`)
    .update({
      xp: 0,
      level: db.val().level + 1
    
    });
    message.channel.send(`parabéns ${message 
      .author} você subiu para o nível ${db.val().level+1}`)
        } else {
    Database.ref(`Servidores/levels/${message.guild.id}/${message.author.id}`)
    .update({
      xp: db.val().xp + gerarXP
      
    });
        }
      } 
      
    });
  });
  

client.on('message', message => {
if (message.channel.id !== "792390451525058570") return

  let responseObject = {
    "oi" : "opa",
    "Oi" : "opa",
    "td bem?" : "estou melhor agr, E vc?",
    "tranquilo" : "tranquilo, e vc?",
    "tranquilo?" : "Tranquilo e vc?",
    "Td bem?" : "estou mt mais felzi agr, E vc?",
    "Tranquilo?" : "Tranquilo, e vc?",
    "Tranquilo" : "Tranquilo, e vc?",
    "De boa" : "melhor agr conversando com vc, mas e vc tá bem?",
    "eu tô bem" : "que ótimo" ,
    "vc tem quantos anos?" : "👀",
    "estou mt bem" : "cara que bom msm <3",
    "tô bem" : "graças a Deus <3",
    "to bem" : "ainda bem<3",
    "kkkk" : ";--------;",
    "K" : "/:",
    "k" : "K"
    
  };

if(responseObject[message.content]){
   message.channel.send(responseObject[message.content]);
}
});


  client.on('message', async message => {
     if (message.channel.type == "dm") return;
     if (message.author.bot) return;
     if (!message.content.toLowerCase().startsWith(config.prefix.toLowerCase())) return;
     if (message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)) return;

    const args = message.content
        .trim().slice(config.prefix.length)
        .split(/ +/g);
    const command = args.shift().toLowerCase();

    try {
        const commandFile = require(`./commands/${command}.js`)
        commandFile.run(client, message, args);
    } catch (err) {
    console.error('Erro:' + err);
let cmdz = new Discord.MessageEmbed()
            .setColor('RANDOM')
            .setTitle('o comando que você deu está errado dê um `r!help` para saber meu comandos')
            .setDescription('')
        message.reply('⠀', cmdz);
  }
});

client.on("guildMemberAdd", async (member) => {

  let emoji = await member.guild.emojis.cache.find(emoji => emoji.name === "");

  let guild = member.guild;
  if (guild === null) return;

  let channel = db.get(`welcome_${member.guild.id}`)
  if (channel === null) return;

  let text = await new Discord.MessageEmbed()
    .setColor("#7c2ae8")
    .setAuthor(member.user.tag, member.user.displayAvatarURL())
    .setTitle(`bem-vindo`)
    .setImage("")
    .setDescription(`**${member.user}** **seja muito 
 bem-vindo(a) ao ${guild.name}**! \n
 *neste momento que você entrou estamos com
 **${member.guild.memberCount}** membros* \n 
 *para ficar sabendo o que você nao deve fazer, leie as regras do servidor*
 *interaja com os membros no chat* \n
 **divirta-se conosco!** <a:ghostwave:782291177697181697>`)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
    .setFooter("Boas vindas")
    .setTimestamp();

  client.channels.cache.get(channel).send(text)

  member.roles.add("777524603017887754"); // Member role.
  member.send(`${member.user} muito obrigado por ter entrando no servidor espero que se divirta-se `)
})

client.on("guildMemberRemove", async (member) => {

    let emoji = await member.guild.emojis.cache.find(emoji => emoji.name === "");

    let guild = member.guild;
    if (guild === null) return;

    let chxLeave = db.get(`leave_${member.guild.id}`)
    if (chxLeave === null) return;

    let textLeave = await new Discord.MessageEmbed()
        .setColor("#7c2ae8")
        .setAuthor(member.user.tag, member.user.displayAvatarURL())
        .setTitle(`alguém saiu`)
        .setImage("")
        .setDescription(`infelizmente ${member.user} saiu do servidor, espero que um dia você volte.`)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
        .setFooter("Goodbay")
        .setTimestamp();

    client.channels.cache.get(chxLeave).send(textLeave)
})

const { APIMessage, Message } = require("discord.js");

Message.prototype.quote = async function (content, options) {
  const reference = {
    message_id: (
      !!content && !options
        ? typeof content === 'object' && content.messageID
        : options && options.messageID
    ) || this.id,
    message_channel: this.channel.id
  }

  const { data: parsed, files } = await APIMessage
    .create(this, content, options)
    .resolveData()
    .resolveFiles()

  let msg = await this.client.api.channels[this.channel.id].messages.post({
    data: { ...parsed, message_reference: reference },
    files
  })

  await this.channel.messages.fetch(msg.id)
            .then(message => msg = message)
            .catch((err) => {
                console.log(err.stack)
            });

  return msg
}




client.on("ready", () => {
  let activities = [
      `Utilize ${config.prefix}help para obter ajuda`,
      `estou em ${client.guilds.cache.size} servidores!`,
      `${client.channels.cache.size} canais!`,
      `${client.users.cache.size} usuários!`,
       `fui criado por X' Pedroじ`,
       `i Love you que está lendo essa mensagem
       `,
       `você que está lendo essa mensagem "3"`
       
    
    ],
    i = 0;
  setInterval( () => client.user.setActivity(`${activities[i++ % activities.length]}`, {
        type: "WATCHING"
      }), 1000 * 30); 
  client.user
      .setStatus("dnd")
      .catch(console.error);
      console.log(`${client.channels.cache.size}`)
console.log("Estou Online, por causa de você!")
});

client.login(process.env.TOKEN); //Ligando o Bot caso ele consiga acessar o token
