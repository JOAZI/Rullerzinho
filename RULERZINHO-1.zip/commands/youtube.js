const Discord = require("discord.js");

 module.exports.run = async(client, message, args) => {
    message.delete();
    if (!args.join(" ")) return message.reply("Digite algo!");
    let search = args.join(' ');
    
    search2 = new URL(`https://www.youtube.com/results?search_query=${search}`)
    
    let embed = new Discord.MessageEmbed()
   
   .setColor("RED")
   .setTitle("<:youtube:790988852717158401>  Pesquisa YouTube <:youtube:790988852717158401> ")
   .setDescription(`Procurando no YouTube...\n[**Resultado**](`+search2+`)\nPesquisa: **${search}**\nAuthor: ${message.author}`)
   
   await message.channel.send(embed)
 }
module.exports.help = {
  name: "search youtube",
  aliases: ['y']
}
