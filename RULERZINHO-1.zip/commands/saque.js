const Discord = require("discord.js");
const db = require("quick.db");
const config = require ("../../config.json");
const color = config.color

exports.run = async (client, message, args) => {
let member = message.author
if (message.content.includes("-"))
    return message.channel.send("Não é permitido valores negativos.");
let saldo = db.get(`banco_${member.id}`)
if (saldo < args[0])
    return message.channel.send("Você não esse valor no seu banco.");
if (!args[0]) return message.channel.send(`Diga o valor a ser sacado.`);
if(isNaN(args[0])){
  return message.channel.send(`Você precisa utilizar numeros!`)
      }
  let embed = new Discord.MessageEmbed()
  .setTitle(`Transferencia`)
  .setDescription(`Voce sacou ${args[0]} para sua carteira`)
  .setThumbnail(member.displayAvatarURL({ dynamic: 'gif', format: 'png', size: 1024 }))
  .setColor(`${color}`)
  .setTimestamp()
  message.channel.send(`<@${member.id}>`, embed)

db.subtract(`banco_${member.id}`, args[0])
db.add(`dinheiro_${member.id}`, args[0])
}
exports.help = {
  name: "saque",
  aliases: ["sacar"]
}

