const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')
const prefix = config.prefix

  module.exports.run = async (client, message, args) => {

    let config = args.slice(0).join(" ")
    if(!config) return message.reply(`Use: ${prefix}setar <welcome/goodbye> <#canal>`)
    let canal = message.mentions.channels.first();
    if(!canal) return message.reply(`Use: ${prefix}setar <welcome/goodbye> <#canal>`)

    if(args[0] == "welcome"){

    if (!message.member.hasPermission('ADMINISTRATOR'))
		  return message.reply('Você precisa da permissão `Administrador`');

  	if (!message.guild.me.hasPermission('ADMINISTRATOR'))
		  return message.reply('Eu preciso da permissão `Administrador`');

    db.set(`welcome_${message.guild.id}`, canal.id)
    message.reply(`O canal de welcome foi setado com sucesso`)
    }

    if(args[0] == "goodbye"){

      if (!message.member.hasPermission('ADMINISTRATOR'))
        return message.reply('Você precisa da permissão `Administrador`');
  
      if (!message.guild.me.hasPermission('ADMINISTRATOR'))
        return message.reply('Eu preciso da permissão `Administrador`');
  
      db.set(`leave_${message.guild.id}`, canal.id)
      message.reply(`O canal do goodbye foi setado com sucesso`)
      }
}