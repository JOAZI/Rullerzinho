const Discord = require('discord.js');
const categories = require('../userCategory');
const util = require('../util');

module.exports = {
	async run(client, message, args) {
		let userMoney = 0;
		if (!args[0]) {
			client.axios.get(`/users/${message.author.id}`).then(res => {
				message.channel.send(
					`\`\`ðŸ’¸\`\` <@${message.author.id}>  seu saldo Ã© de: ${res.data.money} HCoins.`
				);
			});
			return;
		}

		if (!message.member.hasPermission('ADMINISTRATOR')) {
			return message.channel.send(
				new Discord.RichEmbed()
					.setTitle('``âŒ`` Â» Sem permissÃ£o!')
					.setDescription(
						'Infelizmente vocÃª nÃ£o tem permissÃ£o para utilizar esse comando.'
					)
					.setFooter(
						util.getYear() + ' Â© He4rt Developers',
						'https://i.imgur.com/14yqEKn.png'
					)
					.setColor('RED')
					.setTimestamp()
			);
		}

		const member = message.mentions.members.first();
		const quantity = args[2];
		if (!args[0] || !args[1] || isNaN(quantity) || quantity < 1) {
			return message.channel.send(
				'``ðŸŽ²`` Como utilizar o comando: ``!coins <@usuÃ¡rio> <add/remove> <valor>``.'
			);
		}
		if (member) {
			if (args[1] === 'add' && quantity) {
				client.axios
					.post(`/users/${member.id}/money/add`, { value: quantity })
					.then(res => {
						return message.channel.send(
							`\`\`âœ…\`\` Foram adicionados ${quantity} HCoins na conta do usuÃ¡rio <@${member.id}>`
						);
					})
					.catch(err => {
						console.log(err);
					});
			} else if (args[1] === 'remove' && quantity) {
				client.axios
					.post(`/users/${member.id}/money/reduce`, {
						value: quantity,
					})
					.then(res => {
						return message.channel.send(
							`\`\`âŒ\`\` Foram removidos ${quantity} HCoins da conta do usuÃ¡rio <@${member.id}>`
						);
					})
					.catch(err => {
						console.log(err);
					});
			} else if (args[1] === 'enviar' && quantity) {
				client.axios.get(`/users/${message.author.id}`).then(res => {
					userMoney = res.data.money;

					if (userMoney < quantity) {
						return message.channel.send(
							`\`\`â—\`\`  <@${message.author.id}>  seu saldo Ã© menor que ${quantity}.`
						);
					} else {
						client.axios.post(
							`/users/${message.author.id}/money/reduce`,
							{
								value: quantity,
							}
						);
						client.axios
							.post(`/users/${member.id}/money/add`, {
								value: quantity,
							})
							.then(res => {
								return message.channel.send(
									`\`\`âŒ\`\` Foram removidos ${quantity} HCoins da conta do usuÃ¡rio <@${message.author.id}> e adicionados ${quantity} HCoins na conta do usuario <@${member.id}>`
								);
							});
					}
				});
			}
		} else {
			return message.channel.send('``âŒ`` UsuÃ¡rio nÃ£o existente.');
		}
	},

	get command() {
		return {
			name: 'coins',
			category: categories.MOD,
			description:
				'Dar ou Remover uma certa quantia de coins de um determinado user',
			usage: 'coins <@user> <add/remove/enviar> <quantia>',
		};
	},
};