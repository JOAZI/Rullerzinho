const Discord = require("discord.js")

module.exports.run = async (bot, message, args) => {
    let Embed = new Discord.RichEmbed()
    .setColor("RANDOM")
    .setTitle("UserInfo")
    .setAuthor(`${message.author.username} Info`, message.author.displayAvatarURL)
    .addField(`**Nome:**`, `${message.author.username}`, true)
    .addField(`**Tag:**`, `${message.author.discriminator}`, true)
    .addField(`**ID:**`, `${message.author.id}`, true)
    .addField(`**Status:**`, `${message.author.presence.status}`, true)
    .addField(`**Criado em:**`, `${message.author.createdAt}`, true)
    .setFooter(`|UserInfo`, bot.user.displayAvatarURL);
    message.channel.send({embed: sEmbed})
}

module.exports.config = {
    name: "userinfo",
    aliases: ["uinfo", "useri"]
}