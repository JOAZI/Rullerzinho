const Discord = require('discord.js')

module.exports.run = async (bot, message, args) => {
    
if(!args[0]) return message.channel.send('Use dessa forma: <prefix>reverse <texto>');

function reverseString(str) {
    return str.split("").reverse().join("");
}

let sreverse = reverseString(args.join(' '))
 
if(args[0] === sreverse) {

sreverse = `${args.join(' ')}`

}

message.channel.send(sreverse)
  
}