module.exports.run = async (client, message, args) => {
  const m = await message.channel.send('se voce deu ping? eu do pong!!');

  m.edit(`:point_right: **| pong?! **\nEste é o do server: **${m.createdTimestamp -
      message.createdTimestamp}ms.**\nEste é o API : **${Math.round(
      client.ws.ping
    )}ms**`
  );
};