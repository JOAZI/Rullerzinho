const Discord = require('discord.js')
const jimp = require('jimp')

exports.run = async (client, message, args) => {

const frase = args.join(' ');

let perfil = await jimp.read(message.author.displayAvatarURL({format: 'png'}))
let fonte = await jimp.loadFont(jimp.FONT_SANS_64_WHITE)
   let legenda = await jimp.read('https://i.imgur.com/QFrAawH.png')

   perfil.resize(1000, 1000)
   perfil.print(fonte, 130, 900, frase)
   .write('nosso.png');

   message.channel.send('', {files:['nosso.png']});
}
