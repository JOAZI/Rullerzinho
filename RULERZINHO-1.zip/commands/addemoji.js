const Discord = require('discord.js');
const { parse } = require('twemoji-parser');
const { MessageEmbed } = require('discord.js');
const Color = `RANDOM`;

exports.run = async (client, message, args) => {
	if (!message.member.hasPermission(`MANAGE_EMOJIS`)) {
		return message.channel.send(
			`Para executar este comando você precisa possuir a permissão de ``Gerenciar Emojis`` `
		);
	}

	const emoji = args[0];
	if (!emoji)
		return message.channel.send(
			`<a:typing:784850189620871168> ${
				message.author
			}, Você precisa me da o Emoji especifico. \`r!addemoji :nome do emoji:\``
		);

	let customemoji = Discord.Util.parseEmoji(emoji);

	if (customemoji.id) {
		const Link = `https://cdn.discordapp.com/emojis/${customemoji.id}.${
			customemoji.animated ? 'gif' : 'png'
		}`;
		const name = args.slice(1).join(' ');
		message.guild.emojis.create(`${Link}`, `${name || `${customemoji.name}`}`);
		const Added = new MessageEmbed()
			.setTitle(`addemoji Rullerzinho`)
			.setColor(`${Color}`)
			.setDescription(
				`<:teamoS2:785195135671337010> Emoji adicionado com sucesso no servidor.\n ${emoji} adicionado por ${
					message.author
				}.`
			);
		return message.channel.send(Added);
	} else {
		let CheckEmoji = parse(emoji, { assetType: 'png' });
		if (!CheckEmoji[0])
			return message.channel.send(
				`<a:typing:784850189620871168> ${
					message.author
				}, Não fui programado para adicionar link como emoji. Faça desta forma: \`!addemoji <emoji>\`.`
			);
		message.channel.send(
			`Você pode usar normal Emoji sem adicionar Em Servidor!`
		);
	}
};

exports.help = {
	name: 'addemoji',
	aliases: ['addemoji']
};
