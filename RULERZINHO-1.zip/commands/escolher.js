const Discord = require("discord.js");
const ch = args.slice(0).join(" ")

const split = ch.split(",")
let choice = split[Math.floor(Math.random() * split.length)]
message.channel.send(`eu escolho essa parada aqui meu parsero: \`${choice}\``)
