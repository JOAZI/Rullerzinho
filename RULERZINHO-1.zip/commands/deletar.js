const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')
const prefix = config.prefix

  module.exports.run = async (client, message, args) => {

    let config = args.slice(0).join(" ")
    if(!config) return message.reply(`Use: ${prefix}deletar <welcome/goodbay>`)

    if(args[0] == "welcome"){

    if (!message.member.hasPermission('ADMINISTRATOR'))
		  return message.reply('Você precisa da permissão `Administrador`');

  	if (!message.guild.me.hasPermission('ADMINISTRATOR'))
      return message.reply('Eu preciso da permissão `Administrador`');
      
    let chxJoin = db.get(`welcome_${message.guild.id}`)
    if (chxJoin === null) {
      return message.reply("O Canal de boas vindas não está setado")
    }

    db.delete(`welcome_${message.guild.id}`, chxJoin)
    message.reply(`O canal de welcome foi deletado com sucesso`)
    }

    if(args[0] == "goodbay"){

      if (!message.member.hasPermission('ADMINISTRATOR'))
        return message.reply('Você precisa da permissão `Administrador`');
  
      if (!message.guild.me.hasPermission('ADMINISTRATOR'))
        return message.reply('Eu preciso da permissão `Administrador`');
      
      let chx = db.get(`leave_${message.guild.id}`)
      if (chx === null) {
        return message.reply("O canal de saida não está setado")
      }

      db.delete(`leave_${message.guild.id}`, chx)
      message.reply(`O canal de saida foi retirado com sucesso`)
      }
}