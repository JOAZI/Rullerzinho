const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.imgur.com/epyOcSa.gif',
  'https://i.imgur.com/2sSdho4.gif',
  'https://i.imgur.com/VrCxpgb.gif',
  'https://i.imgur.com/5oOcFvG.gif',
  'https://i.imgur.com/iNDaAqw.gif',
  'https://i.imgur.com/qb2KGSY.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para dar um tapa!');
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('TAPA')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de dar um tapa no(a) ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('comando criado por Pedro ')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}