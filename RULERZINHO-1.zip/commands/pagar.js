const Discord = require("discord.js");
const config = require ("../../config.json");
const color = config.color

exports.run = async (client, message, args) => {
    
    let imagem = message.attachments.first()
    
    let comprador = args[0];
    if (!comprador){return message.channel.send(`${message.author}, você precisa marcar o **comprador**!`)
  }
    let produto = args.slice(1).join(" ");
    if (!produto) return message.channel.send(`${message.author}, você precisa especificar o **produto**`)
    try {
    message.channel.send(`${message.author}, seu novo pagamento foi enviado!`).then(msg => msg.delete({ timeout: 10000 }))
    var canal = message.guild.channels.cache.find(ch => ch.id === "755442286006894693");
    const reserva = await canal.send(
     new Discord.MessageEmbed()
      .setTitle(`<a:notinha:742050432242810921> » Novo Pagamento`)
      .setDescription(`\n\nEntregador » ${message.author} \nProduto »  \`${produto}\` \n Usuario »  ${comprador}`)
      .setImage(imagem.url)
      .setTimestamp()
      .setColor(`${color}`)
      )
    } catch (error) {
      return message.channel.send(`${message.author}, Ops.. você esqueceu da imagem!!`)
 } 
}
exports.help = { 
  name: 'pagamento',
  aliases: []
}