const Discord = require('discord.js');
const db = require('quick.db');

module.exports.run = async(client, message, args) => {

 if (!message.member.hasPermission(["MANAGE_GUILD", "ADMINISTRATOR"])) {
    return message.channel.send({embed: {color: "BLUE", description: "Você não pode usar este comando!"}})
  }

    message.channel.send('Você realmente quer ativar a opção: `bloqueador de links de server no discord`?').then(async msg => {
            await msg.react('✅');
            await msg.react('❌');
            const filtro = (reaction, user) =>
                ['✅', '❌'].includes(reaction.emoji.name) &&
                user.id === message.author.id;
            const coletor = msg.createReactionCollector(filtro);

            coletor.on('collect', r => {
                switch (r.emoji.name) {
                    case '✅':
                        msg.reactions.removeAll;
            msg.delete().then(message.channel.send('A função foi ativada com sucesso.\nPara desativar utilize: `-blocklinkoff`'));
            db.delete(`link_${message.guild.id}`, 1)
            db.set(`link_${message.guild.id}`, 2);
                        break;
                    case '❌':
                        msg.reactions.removeAll;
            msg.delete().then(message.channel.send('O ativamento foi cancelado.'));
                        break;
              
                }
            });
        });
} 
