       const EMOJI_REGEX = /:[^:\s]*(?:::[^:\s]*)*:/ 

        if(!EMOJI_REGEX.test(args[0])) {
            return message.channel.send(`Isso não é um emoji!`)
        } else {
            const emoji = args[0].trim().split(':')[2].slice(0, 18)

     const emojis = client.emojis.cache.find(emoje => emoje.id == emoji)
        }
 