const Discord = require("discord.js");
const db = require("quick.db");
const config = require ("../../config.json");
const color = config.color

exports.run = async (client, message, args) => {
let member = message.author
if (message.content.includes("-"))
    return message.channel.send("Não é permitido valores negativos.");
let saldo = db.get(`dinheiro_${member.id}`)
if (saldo < args[0])
    return message.channel.send("Você não esse valor na sua carteira.");
if (!args[0]) return message.channel.send(`Diga o valor a ser depositado.`);
if(isNaN(args[0])){
  return message.channel.send(`Você precisa utilizar numeros!`)
      }
  let embed = new Discord.MessageEmbed()
  .setTitle(`Transferencia`)
  .setDescription(`Voce enviou ${args[0]} para sua conta bancaria`)
  .setThumbnail(member.displayAvatarURL({ dynamic: 'gif', format: 'png', size: 1024 }))
  .setColor(`${color}`)
  .setTimestamp()
  message.channel.send(`<@${member.id}>`, embed)

db.add(`banco_${member.id}`, args[0])
db.subtract(`dinheiro_${member.id}`, args[0])
}
exports.help = {
  name: "depositar",
  aliases: ["dep",`deposit`]
}

