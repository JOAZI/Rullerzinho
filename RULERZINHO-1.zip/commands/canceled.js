const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.imgur.com/UP06WTS.gif',
  'https://i.imgur.com/lVPSzug.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para cancelar para fora da face da terra!');
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('voce foi oficialmente cancelado')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de cancelar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('comando criado por doctor')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}