const Discord = require(`discord.js`);

exports.run = async (bot, message, args) => {
	let embed = new Discord.MessageEmbed()
		.setColor(`RANDOM`)
		.setTitle(`<a:ghostwave:782291177697181697> **Ajudinha do Rullerzinho** <a:ghostwave:782291177697181697>`)
    .setDescription(
			`**Olá, eu sou Rullerzinho 
e essa é minha aba de comandos 
  <a:seta3:782376622892384256> Minhas funções

<a:1lux:782378203460272128> |  Moderação 

<a:2lux:782378239057723433> |  Diversão 

<a:3lux:782378256657678346> |  Utilidades

<a:vm_setaLC:761101422119878686> |  Voltar**`
		)
    .addField("<a:red_estrelinha:782377218948333579> Links", '<a:red_estrelinha:782377218948333579> [Me adicione](https://rullerzin.glitch.me)\n<a:red_firecdm:761099409260937246>[Suporte](https://discord.gg/eGr4HEy4dQ)', false)
		.setFooter(`Executado por ${message.author.username}`)
	message.channel.send(message.author, embed).then(msg => {
		//quando enviar a mensagem...
		msg.react(`782289869534789682`).then(() => {
			//quando reagir o primeiro emoji...
			msg.react(`782378203460272128`);
			msg.react(`782378239057723433`);
			msg.react(`782378256657678346`);
		});

		const voltar = msg.createReactionCollector(
			(reaction, user) =>
				reaction.emoji.id == `782289869534789682` && user.id == message.author.id,
			{ time: 60000 }
		);
		const moderacao = msg.createReactionCollector(
			(reaction, user) =>
				reaction.emoji.id == `782378203460272128` &&
				user.id == message.author.id,
			{ time: 60000 }
		); //time: tempo, 1000 = 1sec, 10000 = 10sec
		const diversao = msg.createReactionCollector(
			(reaction, user) =>
				reaction.emoji.id == `782378239057723433` &&
				user.id == message.author.id,
			{ time: 60000 }
		); //time: tempo, 1000 = 1sec, 10000 = 10sec
		const utilidades = msg.createReactionCollector(
			(reaction, user) =>
				reaction.emoji.id == `782378256657678346` &&
				user.id == message.author.id,
			{ time: 60000 }
		); //time: tempo, 1000 = 1sec, 10000 = 10sec

		utilidades.on(`collect`, r => {
			//quando coletar

			let embed_two = new Discord.MessageEmbed()
				.setColor(`RANDOM`)
				.setTitle(`Comados de Utilidades - Rullerzinho`)
				.setDescription(`**esse são os comandos**
				
<:rx_retro_seta_TKG:782664596728447008> r!icone 
<:dnd:782672257818296330> olhe sua foto é de outras pessoas ampliado

<:rx_retro_seta_TKG:782664596728447008> r!ping
<:dnd:782672257818296330> veja seu ping

<:rx_retro_seta_TKG:782664596728447008> r!say 
<:dnd:782672257818296330> escreva algo para eu falar

<:rx_retro_seta_TKG:782664596728447008> r!ticket 
<:dnd:782672257818296330> dê esse comando se está precisando de suporte

<:rx_retro_seta_TKG:782664596728447008> r!serveinfo
<:dnd:782672257818296330> esse comando eu irei lhe dizer tudo sobre seu servidor!.

<:rx_retro_seta_TKG:782664596728447008> r!banlist
<:dnd:782672257818296330> saiba quantos banimentos já teve nesse serve

<:rx_retro_seta_TKG:782664596728447008> r!lembrete
<:dnd:782672257818296330> esse comando faz que eu possa te lembrar do que você vai fazer.

<:rx_retro_seta_TKG:782664596728447008> r!clima
<:dnd:782672257818296330> saiba quantos graus faz no local onde você mora`
				);
			msg.edit(embed_two);
			r.users.remove(message.author.id); //isso irÃ¡ remover as reaÃ§Ãµes de quem chamou o comando
		});

		diversao.on(`collect`, r => {
			//quando coletar

			let embed_two = new Discord.MessageEmbed()
				.setColor(`RANDOM`)
				.setTitle(`Comados Diversão - Rullerzinho`)
				.setDescription(`**esses são os comandos**
				
<:rx_retro_seta_TKG:782664596728447008> r!ships
<:dnd:782672257818296330> marque 2 pessoas para ver se elas combinam);

<:rx_retro_seta_TKG:782664596728447008> r!slap
<:dnd:782672257818296330> marque alguém para dar um tapâo

<:rx_retro_seta_TKG:782664596728447008> r!hug
<:dnd:782672257818296330> marque alguém para dar um abraço apertado

<:rx_retro_seta_TKG:782664596728447008> r!kiss
<:dnd:782672257818296330> marque alguém para beijar

<:rx_retro_seta_TKG:782664596728447008> r!ball
<:dnd:782672257818296330> faça uma pergunta para mim

<:rx_retro_seta_TKG:782664596728447008> r!true
<:dnd:782672257818296330> me fale uma verdade    

<:rx_retro_seta_TKG:782664596728447008> r!acenar
<:dnd:782672257818296330> marque alguém para acenar

<:rx_retro_seta_TKG:782664596728447008> r!marry
<:dnd:782672257818296330> case com o amor da sua vida

<:rx_retro_seta_TKG:782664596728447008> r!speak
<:dnd:782672257818296330> fale as primeiras palavras do bebê

<:rx_retro_seta_TKG:782664596728447008> r!laranjo
<:dnd:782672257818296330> fale algo para que o pequenino laranjo fale

<:rx_retro_seta_TKG:782664596728447008> r!reverse
<:dnd:782672257818296330> reverta todas as suas palavras

<:rx_retro_seta_TKG:782664596728447008> r!stonks
<:dnd:782672257818296330> se transforme em uma pessoa stonks!!

<:rx_retro_seta_TKG:782664596728447008> r!reverse
<:dnd:782672257818296330> reverta as palavras que você colocar no comando`
);

			msg.edit(embed_two);
			r.users.remove(message.author.id); //isso irÃ¡ remover as reaÃ§Ãµes de quem chamou o comando
		});

		moderacao.on(`collect`, r => {
			//quando coletar

			let embed_two = new Discord.MessageEmbed()
				.setColor(`RANDOM`)
				.setTitle(`Comandos Moderação - Rullerzinho`)
				.setDescription(`**esses são os comandos**
				
<:rx_retro_seta_TKG:782664596728447008> r!ban 
<:dnd:782672257818296330> marque alguém para que possa banir

<:rx_retro_seta_TKG:782664596728447008> r!expulsar
<:dnd:782672257818296330> marque alguém para que possa expulsar

<:rx_retro_seta_TKG:782664596728447008> r!mute
<:dnd:782672257818296330> marque alguém para que seja multado (lembrando que em seu serve você deverá ter um comando de Muted)

<:rx_retro_seta_TKG:782664596728447008> r!warn
<:dnd:782672257818296330> marque e alguém e coloque uma mensagem para que possa o informa o que aconteceu

<:rx_retro_seta_TKG:782664596728447008> r!lento
<:dnd:782672257818296330> altere ou coloque um um tempo para que os membros possam escrever 

<:rx_retro_seta_TKG:782664596728447008> r!thanos
<:dnd:782672257818296330> faça as mensagens desaparecer

<:rx_retro_seta_TKG:782664596728447008> r!lock
<:dnd:782672257818296330> bloqueie um canal

<:rx_retro_seta_TKG:782664596728447008> r!unlock 
<:dnd:782672257818296330> desbloqueie um canal

<:rx_retro_seta_TKG:782664596728447008> r!addemoji
<:dnd:782672257818296330> adicione qualquer emoji em seu servidor

<:rx_retro_seta_TKG:782664596728447008> r!unban
<:dnd:782672257818296330> retire o ban de uma pessoa que você baniu`
);


			msg.edit(embed_two);
			r.users.remove(message.author.id); //isso irÃ¡ remover as reaÃ§Ãµes de quem chamou o comando
		});
		voltar.on(`collect`, r => {
			//quando coletar
			let embed_three = new Discord.MessageEmbed()
				.setColor(`GOLD`)
				.setTitle(`**<a:ghostwave:782291177697181697> Ajudinha do Rullerzinho <a:ghostwave:782291177697181697>**.`)
				.setImage()
				.setDescription(
					`Olá, eu sou Rullerzinho 
e essa daqui minha aba de comandos
<a:aseta_FISH:761101463975362561> Meus comandos:

<a:1lux:782378203460272128> | Moderação 

<a:2lux:782378239057723433> | Diversão

<a:3lux:782378256657678346> | Utilidades

<a:vm_setaLC:761101422119878686> | Voltar`
				)
        .addField("<a:red_estrelinha:782377218948333579> Links", '<a:red_estrelinha:782377218948333579> [Me adicione](https://discord.com/oauth2/authorize?client_id=776259912837627925&scope=bot&permissions=8)\n<a:red_firecdm:761099409260937246> [Suporte](https://discord.gg/eGr4HEy4dQ)', false)
				.setFooter(`Executado por ${message.author.username}`);
			msg.edit(embed_three);
			r.users.remove(message.author.id); //isso irÃ¡ remover as reaÃ§Ãµes de quem chamou o comando
		});
	});
};