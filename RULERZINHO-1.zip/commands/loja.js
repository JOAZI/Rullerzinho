const Discord = require('discord.js')
const db = require('quick.db')
const { default_prefix } = require('../../config.json');

module.exports.run = async (client, message, args) => {
let money = db.get(`dinheiro_${message.author.id}`)

let prefix = db.get(`prefix_${message.guild.id}`)
    if(prefix === null) prefix = default_prefix


    if (!args[0]) {
      return message.channel.send(`${message.author}, Pets a vendas\n**Panda** **Preço: 2500**\n**Gatinho** **Preço: 4500**\n**Flamingo:** **Preço: 5000**\n**Cachorro** **Preço:50000**\n**Peixinho** **Preço: 15000**\n**Ovelinha** **Preço: 25000**\n**Digte r!loja e o nome do pet que deseja compra**\n`) 
    }  
    else if (args[0].toLowerCase() == "panda") {
   if(money < 2500) {
       return message.channel.send('Você não tem 2500 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 909090)
    db.subtract(`dinheiro_${message.author.id}`, 2500)
    return message.channel.send(`Você acaba de comprar um panda por 2500R$`)
    }
    else if (args[0].toLowerCase() == 'gatinho') {
   if(money < 4500) {
       return message.channel.send('Você não tem 4500 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 303030)
    db.subtract(`dinheiro_${message.author.id}`, 4500)
    return message.channel.send(`Você acaba de comprar um Gatinho por 4500R$`)
    }

    else if (args[0].toLowerCase() == "flamingo") {
   if(money < 500) {
       return message.channel.send('Você não tem 500 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 759203)
    db.subtract(`dinheiro_${message.author.id}`, 50000)
    return message.channel.send(`Você acaba de comprar um pet por 500R$`)
    }
    

    else if (args[0].toLowerCase() == "cahorrinho") {
   if(money < 50000) {
       return message.channel.send('Você não tem 50000 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 182306)
    db.subtract(`dinheiro_${message.author.id} `, 5000)
    return message.channel.send(`Você acaba de comprar um pet por 50000R$`)
    }


    else if (args[0].toLowerCase() == "peixinho") {
   if(money < 15000) {
       return message.channel.send('Você não tem 15000 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 999999)
    db.subtract(`dinheiro_${message.author.id}`, 15000)
    return message.channel.send(`Você acaba de comprar um peixinho por 15000R$`)
    }



    else if (args[0].toLowerCase() == 'ovelinha') {
   if(money < 25000) {
       return message.channel.send('Você não tem 25000 Reais para a compra!!')
    }
    db.set(`animalest_${message.author.id}`, 100004)
    db.subtract(`dinheiro_${message.author.id}`, 25000)
    return message.channel.send(`Você acaba de comprar uma ovelinha por 25000R$`)
    }
};
 exports.help = {
  name: 'loja',
  aliases: ['loja','compra']
};