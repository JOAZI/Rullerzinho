const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.imgur.com/Sz5H0tL.gif',
  'https://i.imgur.com/tonmhn6.gif',
  'https://i.imgur.com/5yU1H7g.gif',
  'https://i.imgur.com/gHijWUD.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para abraçar!');
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('hug')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de abraçar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('comando criado por doctorqqer :copyright:')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}