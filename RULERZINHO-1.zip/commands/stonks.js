const DIG = require("discord-image-generation");
const Discord = require('discord.js');

exports.run = async (client, message, args) => {

        // Get the avatarUrl of the user
        let avatar = message.author.displayAvatarURL({ dynamic: false, format: 'png' });
        // Make the image
        let img = await new DIG.Stonk().getImage(avatar);//troque aki o comando n coloque `` se n o comando n pega so coloque  avatar ou texto mais faça o requere do texto da pesoa
        // Add the image as an attachement
        let attach = new Discord.MessageAttachment(img, "stonks.png");
         message.channel.send(attach)

    }