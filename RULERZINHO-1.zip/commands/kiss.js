const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
'https://i.imgur.com/JBtD1yr.gif',
'https://i.imgur.com/4TIFi3d.gif',
'https://i.imgur.com/i5JSj6G.gif',
'https://i.imgur.com/K9GYicD.gif',
'https://i.imgur.com/RG4X4Dm.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para beijar!');
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('beijo')
        .setColor('#000000')
        .setDescription(`${message.author} acabou de beijar alguém`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('voce beijou')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}