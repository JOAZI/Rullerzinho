const ms = require('ms');

exports.run = async (client, message, args) => {

    if(!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        return message.channel.send('<:error:759104378048872478> ⇾ Oops... você não tem permissao para usar este comando.');
    }

    let giveawayChannel = message.mentions.channels.first();
    if(!giveawayChannel){
        return message.channel.send('<:error:759104378048872478> ⇾ Você mencionar um canal válido! **Como usar: r!sorteio <#canal> <minutos> <Número de ganhadores> <titulo>**');
    }

    let giveawayDuration = args[1];
    if(!giveawayDuration || isNaN(ms(giveawayDuration))){
        return message.channel.send('<:error:759104378048872478> Você precisa especificar a duração!');
    }

    let giveawayNumberWinners = args[2];
    if(isNaN(giveawayNumberWinners) || (parseInt(giveawayNumberWinners) <= 0)){
        return message.channel.send('<:error:759104378048872478> ⇾ Você precisa colocar um numero de vencedores válido!');
    }

    let giveawayPrize = args.slice(3).join(' ');
    if(!giveawayPrize){
        return message.channel.send('<:error:759104378048872478> ⇾ Você precisa colocar um prêmio válido!');
    }

    client.giveawaysManager.start(giveawayChannel, {
        time: ms(giveawayDuration),
        prize: giveawayPrize,
        winnerCount: giveawayNumberWinners,
        hostedBy: client.config.hostedBy ? message.author : null,
        messages: {
            giveaway: (client.config.everyoneMention ? "@everyone\n\n" : "")+"🎉🎉 **Sorteio** 🎉🎉",
            giveawayEnded: (client.config.everyoneMention ? "@everyone\n\n" : "")+"🎉🎉 **Sorteio finalizado** 🎉🎉",
            timeRemaining: "Tempo restante: **{duration}**!",
            inviteToParticipate: "Reaja 🎉 para participar!",
            winMessage: "Parabéns, {winners}! Voce ganhou **{prize}**!",
            embedFooter: "Sorteios",
            noWinner: "Sorteio cancelado, sem participações válido.",
            hostedBy: "Criador por: {user}",
            winners: "ganhador(es)",
            endedAt: "Termina em",
            units: {
                seconds: "segundos",
                minutes: "minutos",
                hours: "horas",
                days: "dias",
                pluralS: false
            }
        }
    });

    message.channel.send(`Sorteio iniciado em ${giveawayChannel}!`);

};

exports.help = {
  name: `sorteio`,
  aliases:[`giveaway`]
}