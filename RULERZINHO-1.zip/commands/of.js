const Discord = require('discord.js');
const db = require('quick.db');
exports.run = async (client, message, args) => {
	const Discord = require('discord.js');
	let bruh = new Discord.MessageEmbed();
	message.channel
		.send(bruh)
		.then(console.log)
		.catch(console.error);
	let logs = await db.fetch(`of_${message.guild.id}`);
	if (logs === null) logs = `off`;
	if (logs === 1) logs = `on`;
	const embed = new Discord.MessageEmbed()
		.setTitle('ℹ | Anti-link')
		.setColor('RANDOM')
		.setDescription(
			'Use as reações para tais funções:\n>>> 🔵 = ligado\n🔴 = desligado'
		)
		.setFooter(`Anti-link: ${logs}`);

	message.channel.send(embed).then(msg => {
		msg.react('🔵').then(r => {
			msg.react('🔴').then(r => {});
		});
		const onlogsFilter = (reaction, user) =>
			reaction.emoji.name === '🔵' && user.id === message.author.id;
		const offlogsFilter = (reaction, user) =>
			reaction.emoji.name === '🔴' && user.id === message.author.id;
		const onlogs = msg.createReactionCollector(onlogsFilter);
		const offlogs = msg.createReactionCollector(offlogsFilter);

		onlogs.on('collect', r2 => {
			db.set(`of_${message.guild.id}`, 'on');
			embed.setFooter('Anti-link: on');
			msg.edit(embed);
		});
		offlogs.on('collect', r2 => {
			db.delete(`of_${message.guild.id}`);
			embed.setFooter('Anti-link: off');
			msg.edit(embed);
		});
	});
};
exports.help = {
	name: 'of'
};
