const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.imgur.com/D6BHCeX.gif',
  'https://i.imgur.com/gE84flC.gif',
  'https://i.imgur.com/NhvQqSZ.gif',
  'https://i.imgur.com/9ATiR1I.gif',
  'https://i.imgur.com/Qt9gwGG.gif',
  'https://i.imgur.com/3z4iske.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para acenar!');
}

message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('acenar')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de acenar para ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('acenou')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}