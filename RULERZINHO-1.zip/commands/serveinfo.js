const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "server-info",
    category: "extra",
    run: async (client, message, args) => {
        let region;
        switch (message.guild.region) {
            case "europe":
                region = 'ðŸ‡ªðŸ‡º Europe';
                break;
            case "us-east":
                region = 'ðŸ‡ºðŸ‡¸ us-east'
                break;
            case "us-west":
                region = 'ðŸ‡ºðŸ‡¸ us-west';
                break;
            case "us-south":
                region = 'ðŸ‡ºðŸ‡¸ us-south'
                break;
            case "us-central":
                region = 'ðŸ‡ºðŸ‡¸ us-central'
                break;
        }

        const embed = new MessageEmbed()
            .setThumbnail(message.guild.iconURL({dynamic : true}))
            .setColor('RANDOM')
            .setTitle(`<a:pm_redanuncio:782377324397592576>${message.guild.name} server info`)
            .addFields(
                {
                    name: "<:Conserta:782289963798495254> Dono: ",
                    value: message.guild.owner.user.tag,
                    inline: true
                },
                {
                    name: "<:IconFriends:782290162415304724> Membros: ",
                    value: `Tem ${message.guild.memberCount} Membros!`,
                    inline: true
                },
                {
                    name: "<:IconFriends:782290162415304724> Membros Online: ",
                    value: `Estamos com ${message.guild.members.cache.filter(m => m.user.presence.status == "online").size} Membros online!`,
                    inline: true
                },
                {
                    name: "<:bot2:784543492269015092> Bots: ",
                    value: `Tem ${message.guild.members.cache.filter(m => m.user.bot).size} bots!`,
                    inline: true
                },
                {
                    name: "<a:chazinho:783720902730055710> Data de criação",
                    value: message.guild.createdAt.toLocaleDateString("en-us"),
                    inline: true
                },
                {
                    name: "<:IconPin:782290095574614089> cargos: ",
                    value: `Tem ${message.guild.roles.cache.size} cargos neste servidor.`,
                    inline: true,
                },
                {
                    name: ` Verificado: `,
                    value: message.guild.verified ? 'Servidor Verificado' : `Servidor não verificado`,
                    inline: true
                },
                {
                    name: '<a:Boost:774818247622000651> Boosters: ',
                    value: message.guild.premiumSubscriptionCount >= 1 ? `Tem ${message.guild.premiumSubscriptionCount} Boosters` : `nâo tem boosters`,
                    inline: true
                },
                {
                    name: "<a:g_palmasIF:773190306953748> Emojis: ",
                    value: message.guild.emojis.cache.size >= 1 ? `Tem ${message.guild.emojis.cache.size} emojis!` : 'Não a emojis nesse serve emojis' ,
                    inline: true
                }
            )
        await message.channel.send(embed)
    }
}