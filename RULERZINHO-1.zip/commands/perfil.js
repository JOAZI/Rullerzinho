const discord = require('discord.js');
const db = require('quick.db');
const { default_prefix } = require(`../../config.json`);
const { getInfo } = require('../../handlers/xp.js');

exports.run = async (client, message, args) => {
	let prefix = db.get(`prefix_${message.guild.id}`);
	if (prefix === null) prefix = default_prefix;

	let user = message.mentions.users.first() || message.author;

	const member = message.guild.member(user);
	let nickname =
		member.nickname !== undefined && member.nickname !== null
			? member.nickname
			: `${message.author.username}`; // Nickname

	let money = await db.fetch(`money_${member.id}`);
	if (money === null) money = '0';

	let emprego2 = await db.fetch(`emprego2_${member.id}`);
	if (emprego2 === null)
		emprego2 = `Sem trabalho \nVocê pode mudar isso usando **${prefix}emprego!!**`;

	let like = await db.fetch(`rep_${member.id}`);
	if (like === null) like = '0';

	let marry = await db.get(`marry_${member.id}`);
	let pata = client.users.cache.get(marry);
	if (marry === null) {
		pata = 'Solteiro';
	} else {
		pata = `${pata}`;
	}

	let animalest = await db.fetch(`animalest_${member.id}`); // olhar o valor da variavel
	if (animalest === null) animalest = 'Cachorro'; //caso o valor da variavel for null ele mandara a mensagem como 0
	if (animalest === 909090) animalest = 'Panda'; // panda
	if (animalest === 303030) animalest = 'Phoenix'; // phoeni
	if (animalest === 759203) animalest = 'Flamingo BeBe'; // flamingo bebe
	if (animalest === 182306) animalest = 'Blaze';
	if (animalest === 999999) animalest = 'Loli'; // loli
	if (animalest === 100000) animalest = 'Shukaku & Matatabi'; // shukaku
	if (animalest === 100001) animalest = 'Kurama'; // kurama
	if (animalest === 100002) animalest = 'Juice WRLD'; // Juice WRLD
	if (animalest === 100003) animalest = 'Juubi Privada'; // juubi privada
	if (animalest === 100004) animalest = 'Egirl'; // Egirl
	if (animalest === 12) animalest = 'Ralts'; //Ralts Privado

	let aaa = await db.fetch(`aaa_${member.id}`);
	if (aaa === null)
		aaa = `Sou Parça do Madara \nVocê pode mudar isso usando ${prefix}aboutMe!!`;

	let xp = db.get(`xp_${user.id}_${message.guild.id}`) || 0;
	const { level, remxp, levelxp } = getInfo(xp);
	if (xp === null || xp === 0) xp = '0';

	let embed = new discord.MessageEmbed()
		.setAuthor(message.author.username, message.author.displayAvatarURL())
		.setColor('RED')
		.setThumbnail(
			client.users.cache.get(user.id).displayAvatarURL({ dynamic: true })
		)
		.addField('👥 Nome: ', nickname)
		.addField('👥 ID', user.id, true)
		.addField('📬 Sobre mim: ', aaa)
		.addField('👫 Casado(a) com: ', pata)
		.addField('💵 Moedas: ', money)
		.addField('👍 Likes: ', like)
		.addField('🏙️ Emprego: ', emprego2)
		.addField('🐾 Pets: ', animalest);

	message.channel.send(embed);
}
exports.help = {
  name: "perfil",
  aliases: ["profile"]
};