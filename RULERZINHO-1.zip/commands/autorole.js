const discord = require("discord.js");
const db = require("quick.db");
const { default_prefix } = require("../../config.json");
module.exports.run = async (client, message, args) => {
  const cargo = message.mentions.roles.first();
  let prefix = db.get(`prefix_${message.guild.id}`);
  if (prefix === null) prefix = default_prefix;
  let help = new discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle("__Central de ajuda do comando: autorole.__")
    .setDescription(
      `**Descricão:**\n> Aplicar um cargo quando alguém entrar neste servidor.\n**Exemplo:**\n> ${prefix}autorole @cargo`
    );
  let ops = new discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle("OPS!")
    .setDescription("Você não tem permissão de gerenciar cargos.");
  let okay = new discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle("Okay.")
    .setDescription(
      `O cargo ${cargo} foi configurado para novos membros que entrarem neste servidor.`
    );

  if (!cargo) {
    return message.channel.send(help);
  }
  if (!message.member.hasPermission("ADMINISTRATOR")) {
    return message.channel.send(ops);
  }

  let role = db.set(`cargo_${message.guild.id}`, cargo.id);
  return message.channel.send(okay);
};
exports.help = {
  // setando o nome do arquivo, seguido do prefix
  name: "autorole"
};
