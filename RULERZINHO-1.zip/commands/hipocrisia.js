const Discord = require('discord.js')
const jimp = require('jimp')

exports.run = async (client, message, args) => {

const frase = args.join(' ');

if (message.member.hasPermission('ATTACH_FILES')) {

let dog = await jimp.read('https://www.museudememes.com.br/wp-content/uploads/2020/09/image0.jpg')
let fonte = await jimp.loadFont(jimp.FONT_SANS_128_WHITE)

   dog.resize(2950, 1710)
  dog.print(fonte, 750, 750, frase)
 .write('hipocrisia.png')
   message.channel.send('', {files: ['hipocrisia.png']});
}}