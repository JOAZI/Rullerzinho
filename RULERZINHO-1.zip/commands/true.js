var fortunes = [
    "Obrigado pela sua honestidade.",
    "QUE",
    "Não é verdade",
    "poxa;-;",
    "contou meu segredo",
    "Isso é um mistério",
    "você nao disso isso nao né?;-;",
    "Meu informante disse o contrário",
    "éhhh...",
    "num ligo!",
    "tu também!",
    "Na-",
    "ué",
    "verdade!",
    ";-;",

  ];
  
  exports.run = (bot, msg, params) => {
  
    if(!params[0]){
      return msg.channel.send("❌ " + "| não deu!")
    }
    if (params[0]) msg.channel.send(fortunes[Math.floor(Math.random() * fortunes.length)]);
    else msg.channel.send("❌ " + "| num deu! :(");
  
  };